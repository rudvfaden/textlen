# returns the lenght of a string

A very simple cli tool that just returns the length of a string
