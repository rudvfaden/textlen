# returns the lenght of a string
